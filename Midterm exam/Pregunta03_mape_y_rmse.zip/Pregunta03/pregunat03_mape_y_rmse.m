load reales.txt
load predichos.txt

mape = sum(abs((reales - predichos)./reales))*(100/12);
% mape = 6.08690%

rmse = sqrt(sum((reales - predichos).^2)/12);
% rmse = 29982791.28
