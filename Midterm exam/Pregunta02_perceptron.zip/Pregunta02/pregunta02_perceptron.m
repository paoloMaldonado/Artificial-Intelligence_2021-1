input1 = [1 1 1];
input2 = [1 1 -1];
input3 = [1 -1 1];
input4 = [1 -1 -1];


w1 = [0.8728; 0.1854; 0.5945];

output1 = input1*w1;
output2 = input2*w1;
output3 = input3*w1;
output4 = input4*w1;
