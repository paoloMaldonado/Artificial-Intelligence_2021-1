serie = zeros(12,2);
serie(:,1) = serieFinal;
serie(:,2) = valoutDesnormalizado;

y = zeros(7,1);
for n=1:12
    y(n,1) = n;
end


